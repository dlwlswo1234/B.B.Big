from django.apps import AppConfig


class YoloConfig(AppConfig):
    name = 'yolo'
